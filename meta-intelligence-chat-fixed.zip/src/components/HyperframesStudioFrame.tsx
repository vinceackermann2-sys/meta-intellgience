import { useEffect, useMemo, useState } from 'react';
import { Loader2, RefreshCw, AlertCircle } from 'lucide-react';
import { buildHyperframesStudioUrl, getActiveHyperframesProjectId } from '../lib/hyperframes';

export default function HyperframesStudioFrame() {
  const [projectId, setProjectId] = useState<string>('project');
  const [refreshKey, setRefreshKey] = useState(0);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');

  useEffect(() => {
    let cancelled = false;
    getActiveHyperframesProjectId()
      .then((id) => {
        if (cancelled) return;
        setProjectId(id);
        setStatus('ready');
      })
      .catch((error) => {
        console.error('[HYPERFRAMES STUDIO] Failed to resolve project:', error);
        if (!cancelled) setStatus('error');
      });

    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    const handleSuccess = () => setRefreshKey((key) => key + 1);
    window.addEventListener('hyper-edit-success', handleSuccess);
    return () => window.removeEventListener('hyper-edit-success', handleSuccess);
  }, []);

  const studioUrl = useMemo(() => buildHyperframesStudioUrl(projectId, refreshKey), [projectId, refreshKey]);

  if (status === 'loading') {
    return (
      <div className="w-full h-full flex items-center justify-center bg-slate-950 text-slate-200">
        <div className="flex items-center gap-3 text-sm font-semibold">
          <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
          Loading original Hyperframes Studio…
        </div>
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="w-full h-full flex items-center justify-center bg-slate-950 text-slate-200 p-8">
        <div className="max-w-md rounded-2xl border border-amber-400/30 bg-amber-400/10 p-5">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-300 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-white">Hyperframes Studio is still booting</h3>
              <p className="text-sm text-slate-300 mt-1">The preview server did not answer yet. Refresh the Studio view after the server finishes starting.</p>
              <button
                onClick={() => {
                  setStatus('loading');
                  getActiveHyperframesProjectId()
                    .then((id) => {
                      setProjectId(id);
                      setStatus('ready');
                      setRefreshKey((key) => key + 1);
                    })
                    .catch(() => setStatus('error'));
                }}
                className="mt-4 inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2 text-xs font-bold text-white hover:bg-white/15 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Retry
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex flex-col bg-slate-950">
      <div className="h-11 px-4 border-b border-white/10 bg-slate-950 flex items-center justify-between text-slate-200 shrink-0">
        <div className="flex items-center gap-3">
          <span className="text-xs font-black uppercase tracking-widest text-indigo-300">Original Hyperframes Studio</span>
          <span className="text-[11px] font-mono text-slate-500">project: {projectId}</span>
        </div>
        <button
          onClick={() => setRefreshKey((key) => key + 1)}
          className="inline-flex items-center gap-2 rounded-lg border border-white/10 px-2.5 py-1.5 text-[11px] font-bold text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Reload Studio
        </button>
      </div>
      <iframe
        key={`${projectId}-${refreshKey}`}
        title="Original Hyperframes Studio"
        src={studioUrl}
        className="w-full flex-1 border-0 bg-slate-950"
        allow="fullscreen; clipboard-read; clipboard-write"
      />
    </div>
  );
}
