import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, FastForward, Rewind, ZoomIn, ZoomOut, Maximize2, Volume2, Plus, Sliders, Scissors, Video, Music, Type, Check, RefreshCw, Layers, Film } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Mock Track Elements
interface TimelineClip {
  id: string;
  type: 'video' | 'audio' | 'text';
  name: string;
  start: number; // in seconds
  duration: number; // in seconds
  color: string;
}

export const StudioApp: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(3.5); // seconds
  const [duration, setDuration] = useState(15); // total duration
  const [zoom, setZoom] = useState(10); // scale factor
  const [activeClipId, setActiveClipId] = useState<string | null>('v1');
  const [isProcessingAI, setIsProcessingAI] = useState(false);
  const [hasNewGen, setHasNewGen] = useState(false);

  // Core Playback State
  const animationRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(Date.now());

  // Listen for AI Generative Cuts
  useEffect(() => {
    const handleHyperEditSuccess = () => {
      setIsProcessingAI(true);
      setTimeout(() => {
        setIsProcessingAI(false);
        setHasNewGen(true);
        setCurrentTime(0);
        setIsPlaying(true);
      }, 2500);
    };

    window.addEventListener('hyper-edit-success', handleHyperEditSuccess);
    return () => {
      window.removeEventListener('hyper-edit-success', handleHyperEditSuccess);
    };
  }, []);

  // Frame Loop for Player Simulation
  useEffect(() => {
    if (isPlaying) {
      const updateFrame = () => {
        const now = Date.now();
        const delta = (now - lastTimeRef.current) / 1000;
        lastTimeRef.current = now;

        setCurrentTime((prev) => {
          let next = prev + delta;
          if (next >= duration) {
            next = 0;
          }
          return next;
        });

        animationRef.current = requestAnimationFrame(updateFrame);
      };

      lastTimeRef.current = Date.now();
      animationRef.current = requestAnimationFrame(updateFrame);
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, duration]);

  // Handle Seek Click on Track
  const handleTimelineSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const progress = clickX / rect.width;
    setCurrentTime(progress * duration);
  };

  // Clips setup
  const clips: TimelineClip[] = hasNewGen ? [
    { id: 'v1', type: 'video', name: 'AI Hype Reel - Hook.mp4', start: 0, duration: 4.5, color: 'bg-indigo-500 border-indigo-400' },
    { id: 'v2', type: 'video', name: 'A-Roll Talking Segment.mp4', start: 4.5, duration: 6, color: 'bg-indigo-500 border-indigo-400' },
    { id: 'v3', type: 'video', name: 'B-Roll Demonstration.mp4', start: 10.5, duration: 4.5, color: 'bg-indigo-500 border-indigo-400' },
    { id: 'a1', type: 'audio', name: 'Ambient Beat.wav', start: 0, duration: 15, color: 'bg-emerald-500 border-emerald-400' },
    { id: 't1', type: 'text', name: 'Captions: "HEY FOLKS..."', start: 0.5, duration: 3.5, color: 'bg-amber-500 border-amber-400' },
    { id: 't2', type: 'text', name: 'Captions: "CHECK THIS OUT!"', start: 4.5, duration: 5, color: 'bg-amber-500 border-amber-400' }
  ] : [
    { id: 'v1', type: 'video', name: 'Original Raw Footage.mp4', start: 0, duration: 12, color: 'bg-indigo-600/70 border-indigo-500/70' },
    { id: 'a1', type: 'audio', name: 'Default Audio Track.wav', start: 0, duration: 15, color: 'bg-emerald-600/70 border-emerald-500/70' }
  ];

  return (
    <div id="hyperframes-studio-wrap" className="w-full h-full flex flex-col bg-slate-950 text-slate-100 font-sans select-none overflow-hidden relative">
      
      {/* Processing Loader Overlay */}
      <AnimatePresence>
        {isProcessingAI && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-slate-950/90 z-50 flex flex-col items-center justify-center gap-4 border border-indigo-500/30"
          >
            <div className="relative flex items-center justify-center">
              <div className="w-16 h-16 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
              <Film className="w-6 h-6 text-indigo-400 absolute animate-pulse" />
            </div>
            <div className="text-center">
              <h3 className="text-lg font-bold text-white tracking-tight">Vibe-Cutting Active</h3>
              <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest font-black">AI is slicing & syncing timeline blocks...</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Editor Main Content: Top Screen Split */}
      <div className="flex-1 flex min-h-0">
        
        {/* Left Side: Mock Source/Project Assets */}
        <aside className="w-64 border-r border-slate-900 flex flex-col bg-slate-950 shrink-0 hidden md:flex">
          <div className="p-4 border-b border-slate-900 flex items-center justify-between">
            <span className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
              <Layers className="w-3.5 h-3.5 text-indigo-400" /> Source Media
            </span>
            <button className="p-1 hovered:bg-slate-900 rounded text-slate-400 hover:text-white transition-all">
              <Plus className="w-4 h-4" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-3 space-y-2 custom-scrollbar">
            <div className="p-2.5 rounded-xl bg-slate-900/50 border border-slate-800/80 flex items-center gap-3">
              <div className="w-10 h-10 rounded bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                <Video className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold truncate">AI Hype Reel.mp4</p>
                <p className="text-[10px] text-slate-500">1080x1920 · 15.0s</p>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-900/20 border border-slate-900 flex items-center gap-3">
              <div className="w-10 h-10 rounded bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Music className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold truncate">SynthWave Beat.wav</p>
                <p className="text-[10px] text-slate-500">44.1kHz · Stereo</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Middle Area: Video Canvas Monitor */}
        <div className="flex-1 bg-slate-900/30 flex flex-col items-center justify-center p-6 relative">
          
          {/* Virtual Canvas Box (Responsive Fit to Timeline Mode) */}
          <div className="aspect-[9/16] h-[340px] md:h-[420px] bg-black rounded-3xl border border-slate-800 flex flex-col relative overflow-hidden shadow-2xl">
            {/* Realtime Subtitles overlay */}
            {isPlaying && (
              <div className="absolute top-1/2 left-0 right-0 transform -translate-y-1/2 flex items-center justify-center text-center px-4 z-20 pointer-events-none">
                {currentTime < 4.5 ? (
                  <motion.p key="cap1" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1.1, opacity: 1 }} className="text-2xl font-black italic bg-amber-400 text-slate-950 px-4 py-1.5 rounded-lg shadow-2xl tracking-tight uppercase">
                    🚀 HEY FOLKS!
                  </motion.p>
                ) : currentTime < 10.5 ? (
                  <motion.p key="cap2" initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1.1, opacity: 1 }} className="text-xl font-black bg-indigo-600 text-white px-3.5 py-1 rounded-md shadow-2xl tracking-wide uppercase">
                    💥 CHECK THE ANALYTICS!
                  </motion.p>
                ) : null}
              </div>
            )}

            {/* Simulated Frame Preview with animated glow */}
            <div className="flex-1 flex flex-col items-center justify-center relative overflow-hidden bg-slate-950">
              {hasNewGen ? (
                <>
                  <div className="absolute inset-0 opacity-40 bg-radial-gradient from-indigo-500/20 via-transparent to-transparent animate-pulse" />
                  <div className="text-center p-4">
                    <Video className="w-12 h-12 text-indigo-400 mx-auto opacity-70 mb-2" />
                    <span className="text-xs font-black uppercase tracking-wider text-indigo-300">Generative Output Active</span>
                    <p className="text-[10px] text-slate-500 mt-2">Active frame sync: {currentTime.toFixed(2)}s</p>
                  </div>
                </>
              ) : (
                <div className="text-center p-4">
                  <Film className="w-12 h-12 text-slate-600 mx-auto mb-2" />
                  <span className="text-xs font-semibold text-slate-400">Idle Canvas</span>
                  <p className="text-[10px] text-slate-600 mt-1 font-mono">Ready for compilation</p>
                </div>
              )}
            </div>

            {/* Playback Progress Indicator Bar inside Monitor */}
            <div className="h-1 bg-slate-900 w-full relative">
              <div className="absolute top-0 bottom-0 left-0 bg-indigo-500" style={{ width: `${(currentTime / duration) * 100}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* Editor Bottom Content: Timeline & Multitrack Workspace */}
      <div className="h-72 border-t border-slate-900 bg-slate-950 flex flex-col relative shrink-0">
        
        {/* Timeline Control Rail */}
        <div className="h-12 bg-slate-950/80 border-b border-slate-900/50 px-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-xs font-mono font-bold text-slate-400 bg-slate-900/80 border border-slate-800 px-2.5 py-1 rounded-md">
              {Math.floor(currentTime / 60).toString().padStart(2, '0')}:
              {(Math.floor(currentTime) % 60).toString().padStart(2, '0')}:
              {Math.floor((currentTime % 1) * 30).toString().padStart(2, '0')}
            </span>
            <div className="flex items-center gap-2">
              <button onClick={() => setCurrentTime(0)} className="p-1 px-1.5 hover:bg-slate-900 rounded text-slate-400 hover:text-white transition-all"><Rewind className="w-4 h-4" /></button>
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-8 h-8 rounded-full bg-indigo-500 hover:bg-indigo-400 text-white flex items-center justify-center transition-all shadow-md active:scale-95"
              >
                {isPlaying ? <Pause className="w-4 h-4 py-0" /> : <Play className="w-4 h-4 ml-0.5" />}
              </button>
              <button onClick={() => setCurrentTime(duration)} className="p-1 px-1.5 hover:bg-slate-900 rounded text-slate-400 hover:text-white transition-all"><FastForward className="w-4 h-4" /></button>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              <button onClick={() => setZoom(Math.max(5, zoom - 2))} className="p-1.5 hover:bg-slate-900 rounded text-slate-400 hover:text-white"><ZoomOut className="w-4 h-4" /></button>
              <span className="text-[10px] font-bold text-slate-500">{zoom}x</span>
              <button onClick={() => setZoom(Math.min(25, zoom + 2))} className="p-1.5 hover:bg-slate-900 rounded text-slate-400 hover:text-white"><ZoomIn className="w-4 h-4" /></button>
            </div>
            <button className="p-1.5 hover:bg-slate-900 rounded text-slate-400 hover:text-white transition-all"><Maximize2 className="w-4 h-4" /></button>
          </div>
        </div>

        {/* Multi-Track Interactive Timelines Area */}
        <div 
          className="flex-1 overflow-x-auto overflow-y-hidden custom-scrollbar bg-slate-950/40 relative"
          onClick={handleTimelineSeek}
        >
          {/* Vertical Playhead Rule Indicator */}
          <div 
            className="absolute top-0 bottom-0 w-[2px] bg-red-500 pointer-events-none z-30 shadow-[0_0_12px_rgba(239,68,68,0.5)]"
            style={{ left: `${(currentTime / duration) * 100}%` }}
          />

          {/* Time ruler ticks */}
          <div className="h-6 border-b border-slate-900/30 flex items-end relative" style={{ width: '100%' }}>
            {Array.from({ length: duration + 1 }).map((_, i) => (
              <span 
                key={i} 
                className="absolute text-[9px] font-mono font-bold text-slate-600 border-l border-slate-900 h-2.5 pl-1 flex items-end leading-none"
                style={{ left: `${(i / duration) * 100}%` }}
              >
                {i}s
              </span>
            ))}
          </div>

          {/* Multi-Tracks Blocks */}
          <div className="flex-1 flex flex-col py-1 space-y-1.5 px-1 relative">
            
            {/* Visual Track 1: Video Blocks */}
            <div className="h-10 border border-slate-900 bg-slate-900/20 rounded-xl relative flex items-center px-4">
              <span className="absolute left-2.5 text-[8px] font-black uppercase tracking-widest text-slate-500 bg-slate-950 px-1 rounded z-20">Video Track</span>
              {clips.filter(c => c.type === 'video').map(clip => (
                <div
                  key={clip.id}
                  onClick={(e) => { e.stopPropagation(); setActiveClipId(clip.id); }}
                  className={`absolute h-8 ${clip.color} rounded-lg border text-white text-[10px] font-bold px-3 flex items-center justify-between cursor-pointer transition-all ${activeClipId === clip.id ? 'ring-2 ring-indigo-400 scale-[1.01] shadow-2xl' : 'opacity-70 hover:opacity-100'}`}
                  style={{
                    left: `${(clip.start / duration) * 100}%`,
                    width: `${(clip.duration / duration) * 100}%`,
                  }}
                >
                  <span className="truncate max-w-[140px]">{clip.name}</span>
                  <span className="text-[8px] font-mono text-white/60">{clip.duration.toFixed(1)}s</span>
                </div>
              ))}
            </div>

            {/* Audio Track 2: Music Blocks */}
            <div className="h-10 border border-slate-900 bg-slate-900/20 rounded-xl relative flex items-center px-4">
              <span className="absolute left-2.5 text-[8px] font-black uppercase tracking-widest text-slate-400 bg-slate-950 px-1 rounded z-20">Audio Track</span>
              {clips.filter(c => c.type === 'audio').map(clip => (
                <div
                  key={clip.id}
                  onClick={(e) => { e.stopPropagation(); setActiveClipId(clip.id); }}
                  className={`absolute h-8 ${clip.color} rounded-lg border text-white text-[10px] font-bold px-3 flex items-center justify-between cursor-pointer transition-all ${activeClipId === clip.id ? 'ring-2 ring-emerald-400 scale-[1.01] shadow-2xl' : 'opacity-70 hover:opacity-100'}`}
                  style={{
                    left: `${(clip.start / duration) * 100}%`,
                    width: `${(clip.duration / duration) * 100}%`,
                  }}
                >
                  <span className="truncate max-w-[140px]">{clip.name}</span>
                  <span className="text-[8px] font-mono text-white/60">{clip.duration.toFixed(1)}s</span>
                </div>
              ))}
            </div>

            {/* Captions Track 3: Subtitles / Overlay */}
            <div className="h-10 border border-slate-900 bg-slate-900/20 rounded-xl relative flex items-center px-4">
              <span className="absolute left-2.5 text-[8px] font-black uppercase tracking-widest text-slate-400 bg-slate-950 px-1 rounded z-20">Caption Track</span>
              {clips.filter(c => c.type === 'text').map(clip => (
                <div
                  key={clip.id}
                  onClick={(e) => { e.stopPropagation(); setActiveClipId(clip.id); }}
                  className={`absolute h-8 ${clip.color} rounded-lg border text-white text-[10px] font-bold px-3 flex items-center justify-between cursor-pointer transition-all ${activeClipId === clip.id ? 'ring-2 ring-amber-400 scale-[1.01] shadow-2xl' : 'opacity-70 hover:opacity-100'}`}
                  style={{
                    left: `${(clip.start / duration) * 100}%`,
                    width: `${(clip.duration / duration) * 100}%`,
                  }}
                >
                  <span className="truncate max-w-[140px]">{clip.name}</span>
                  <span className="text-[8px] font-mono text-white/60">{clip.duration.toFixed(1)}s</span>
                </div>
              ))}
            </div>

          </div>
        </div>
      </div>

    </div>
  );
};
